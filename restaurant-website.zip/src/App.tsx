import Hero from "./component/hero";
import AboutUs from "./component/AbountUs";
import Specialties from "./component/Specialties";
import Menu from "./component/Menu";
import Footer from "./component/Footer";
import ItalianMenu from "./component/ItalianMenu";
import "./App.css";
function App() {
  return (
    <>
      <Hero />
      <AboutUs />
      <Specialties />
      <Menu />
      <ItalianMenu />
      <Footer />
    </>
  );
}
export default App;
