import LogoIcon from "../component/LogoIcon";
import menu from "../assets/images/menu.png";
const Navbar = () => {
  return (
    <header>
      <div className="w-[1350px] p-10 flex h-[30px]">
        <div className="flex w-[30%]">
          <LogoIcon />
          <p className="cursor-pointer text-[30px] pl-2 leading-8 font-serif text-white font-[600]">Italian <br />Food</p>
        </div>
        <div className="w-[40%] text-white flex justify-around mt-3 font-[500] text-[22px]">
          <div className=" flex justify-center items-center w-[50px]">
            <span className="hover:underline hover:font-[700]">Home</span>
          </div>
          <div className="cursor-pointer flex justify-center items-center w-[50px]">
            <span className="hover:underline hover:font-[700]">Info</span>
          </div>
          <div className="cursor-pointer flex justify-center items-center w-[50px]">
            <span className="hover:underline hover:font-[700]">Event</span>
          </div>
          <div className="cursor-pointer flex justify-center items-center w-[50px]">
            <span className="hover:underline hover:font-[700]">Menu</span>
          </div>
          <div className="cursor-pointer flex justify-center items-center w-[50px]">
            <span className="hover:underline hover:font-[700]">Contact</span>
          </div>
        </div>
        <div className="w-[30%] flex justify-end  ">
          <div className="flex bg-[#f1f1f1] h-[40px] rounded-4xl w-[220px] border-gray-600 justify-between p-1 border-[0.2px] mr-20">
            <div className="px-5">
              <input
                placeholder=""
                className=" focus:border-transparent focus:outline-none border-0 h-[30px]  w-[130px] "
                type="text"
              />
            </div>
            <div className="mx-2 my-1">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                x="0px"
                y="0px"
                width="20"
                height="20"
                viewBox="0 0 50 50"
              >
                <path d="M 21 3 C 11.621094 3 4 10.621094 4 20 C 4 29.378906 11.621094 37 21 37 C 24.710938 37 28.140625 35.804688 30.9375 33.78125 L 44.09375 46.90625 L 46.90625 44.09375 L 33.90625 31.0625 C 36.460938 28.085938 38 24.222656 38 20 C 38 10.621094 30.378906 3 21 3 Z M 21 5 C 29.296875 5 36 11.703125 36 20 C 36 28.296875 29.296875 35 21 35 C 12.703125 35 6 28.296875 6 20 C 6 11.703125 12.703125 5 21 5 Z"></path>
              </svg>
            </div>
          </div>
          <img className="cursor-pointer m-1 w-[30px] h-[30px]" src={menu} alt="" />
        </div>
      </div>
    </header>
  );
};

export default Navbar;
