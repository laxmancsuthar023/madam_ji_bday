import heroimg from "../assets/images/Hero_img.jpg";
import Navbar from "./navbar";
const Hero = () => {
  return (
    <section>
      <div className="absolute">
      <Navbar/>
      </div>
      <div
        className=" h-[668px] w-full text-white flex flex-col justify-center align-middle items-center text-center  "
        style={{
          backgroundImage: `url(${heroimg})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          height: "668px",
          width: "100%",
        }}
      >
        <p className="leading-30 font-[700] font-serif text-[120px]">Italian</p>
        <p className="text-[45px] font-serif font-[600]">. Delicious Food .</p>
        <p className="h-[45px] mt-5 rounded-4xl text-[20px] p-1.5 cursor-pointer font-[500] w-[140px] text-black bg-white">SEE MORE</p>
        <p className="text-[33px] font-serif font-[600] mt-5">Call Us!</p>
      </div>
    </section>
  );
};

export default Hero;
