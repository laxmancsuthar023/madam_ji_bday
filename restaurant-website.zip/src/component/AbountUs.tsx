import AbountusImg from '../assets/images/about.png'
const AboutSection = () => {
  return (
    <section>
      <div className='grid grid-cols-2 gap-15 p-25 '>
        <div>
          <span className='font-[700] font-serif text-[70px]'>About us</span>
          <p className='text-[33px] font-[600]'>The Best Food & Drinks </p>
          <div className='border-b-3 border-gray-500 w-[500px] mt-10' ></div>
          <p className='text-[29px] pr-6 mt-10 text-gray-500 font-[400]'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ad itaque, nostrum inventore incidunt repellendus excepturi provident consequuntur perferendis maxime illum voluptatum nobis possimus delectus sequi debitis praesentium qui autem amet.</p>
        </div>
        <div className='h-[600px] object-fill  overflow-hidden'>
          <img className='' src={AbountusImg} alt="" />
        </div>
      </div>
    </section>
  );
};

export default AboutSection;