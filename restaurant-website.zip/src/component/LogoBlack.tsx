import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUtensils } from "@fortawesome/free-solid-svg-icons";

const LogoBlack = () => {
  return (
    <FontAwesomeIcon icon={faUtensils} size="4x" color='#000000' />
  );
};

export default LogoBlack;