import React from "react";

const ItalianMenu: React.FC = () => {
  const items = [
    { title: "Pizza", desc: "Lorem ipsum dolor sit amet consectetur adipiscing elit, sed do", price: "$00" },
    { title: "Soup", desc: "Lorem ipsum dolor sit amet consectetur adipiscing elit, sed do", price: "$00" },
    { title: "Toast", desc: "Lorem ipsum dolor sit amet consectetur adipiscing elit, sed do", price: "$00" },
  ];
  const itemsRight = [
    { title: "Pasta", desc: "Lorem ipsum dolor sit amet consectetur adipiscing elit, sed do", price: "$00" },
    { title: "Salad", desc: "Lorem ipsum dolor sit amet consectetur adipiscing elit, sed do", price: "$00" },
    { title: "Tiramisu", desc: "Lorem ipsum dolor sit amet consectetur adipiscing elit, sed do", price: "$00" },
  ];
  return (
    <section className="bg-gray-900 text-gray-100 py-16 px-4">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-4xl font-serif text-rose-400 mb-2">Fresh Food</h2>
        <h1 className="text-5xl font-serif text-rose-400 mb-4">. Italian Food .</h1>
        <p className="text-sm uppercase tracking-widest text-white">Menu</p>
      </div>

      <div className="mt-12 max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Left column */}
        <div className="space-y-8">
          {items.map((item) => (
            <div key={item.title}>
              <div className="flex justify-between items-center">
                <h3 className="text-2xl font-semibold">{item.title}</h3>
                <span className="text-xl">{item.price}</span>
              </div>
              <hr className="border-gray-700 my-2" />
              <p className="text-gray-400 text-sm">{item.desc}</p>
            </div>
          ))}
        </div>

        {/* Right column */}
        <div className="space-y-8">
          {itemsRight.map((item) => (
            <div key={item.title}>
              <div className="flex justify-between ">
                <h3 className="text-2xl font-semibold">{item.title}</h3>
                <span className="text-xl">{item.price}</span>
              </div>
              <hr className="border-gray-700 my-2" />
              <p className="text-gray-400 text-sm">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ItalianMenu;
