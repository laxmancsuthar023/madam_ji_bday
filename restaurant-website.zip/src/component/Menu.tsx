import menu1 from "../assets/images/menu1.jpg";
import menu2 from "../assets/images/menu2.jpg";
import menu3 from "../assets/images/menu3.jpg";
type Card = {
  img: string;
  title: string;
  description: string;
};

const cards: Card[] = [
  {
    img: menu1,
    title: "Spaghetti",
    description:
      "Lorem ipsum dolor amet, consectetur adipiscing sed do eiusmod tempor incididunt ut labore",
  },
  {
    img: menu2,
    title: "Lasagna",
    description:
      "Lorem ipsum dolor amet, consectetur adipiscing sed do eiusmod tempor incididunt ut labore",
  },
  {
    img: menu3,
    title: "Tiramisu",
    description:
      "Lorem ipsum dolor amet, consectetur adipiscing sed do eiusmod tempor incididunt ut labore",
  },
];

const Menu = () => (
  <section className="p-25">
    <div className="grid grid-cols-3">
      {cards.map((e) => (
        <div>
          <div className="flex flex-col justify-center text-left items-center">
            <img
              className="h-[250px] w-[250px] rounded-full "
              src={e.img}
              alt=""
            />
          </div>
          <p className="ml-20 mt-10 text-[35px] text-left font-serif font-[600]">
            {e.title}
          </p>
          <p className="ml-20 pr-15 rounded-4xl text-[15px] text-black bg-white">{e.description}</p>
          <div className="border-b-2 ml-20 mt-5 border-gray-500 w-[250px]"></div>
          <div className="flex justify-center items-center">
          <p className="h-[45px] mt-5 rounded-4xl text-[20px] px-5 py-2 font-[500] w-[140px] cursor-pointer text-white bg-orange-600">SEE MORE</p>
          </div>
        </div>
      ))}
    </div>
  </section>
);

export default Menu;
