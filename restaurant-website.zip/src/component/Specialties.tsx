import SpecialPhoto from "../assets/images/Specilities.jpg";
const Specialties = () => {
  return (
    <section className="bg-black opacity-75">
      <div
        className="w-full h-[300px] flex flex-col justify-center items-center"
        style={{
          backgroundImage: `url(${SpecialPhoto})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          width: "100%",
        }}
      >
         <p className="text-[45px] text-white font-serif font-[600]">Our Specilities</p>
         <p className="text-[33px] text-white font-serif font-[600] mt-5">LOREM IPSUM DOLOR SIT AMET</p>
         <p className="h-[45px] mt-5 rounded-4xl text-[20px] px-5 py-2 font-[500] w-[140px] text-white bg-orange-600">SEE MORE</p>
      </div>
    </section>
    // <section
    //   className="relative h-96 bg-cover bg-center flex items-center justify-center"
    //   style={{ backgroundImage: SpecialPhoto }}
    // >
    //   <div className=" inset-0  bg-opacity-40" />

    //   {/* Content */}
    //   <div className="relative z-10 text-center text-white px-4">
    //     <h2 className="text-4xl md:text-5xl font-serif mb-2">
    //       Our Specialities
    //     </h2>
    //     <p className="uppercase text-sm md:text-base tracking-widest mb-6">
    //       Lorem ipsum dolor sit amet
    //     </p>
    //     <button className="bg-red-500 hover:bg-red-600 text-white px-6 py-2 rounded-full text-lg">
    //       See More
    //     </button>
    //   </div>
    // </section>
  );
};

export default Specialties;
