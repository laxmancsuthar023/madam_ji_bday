import footer_img from "../assets/images/footer_img.jpg";
import LogoIcon from "../component/LogoIcon";
import LogoBlack from "./LogoBlack";
const Footer = () => {
  const ar = [1,2,3]
  return (
    <footer className="">
      <div
        className="w-full h-[300px] flex flex-col justify-center items-center"
        style={{
          backgroundImage: `url(${footer_img})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          width: "100%",
        }}
      >
        <div className="flex ">
          <LogoIcon />
          <p className="text-[30px] pl-2 leading-8 font-serif text-white font-[600]">
            Italian <br />
            Food
          </p>
        </div>
        <p className="text-[25px] text-white font-serif font-[600] mt-5">
          LOREM IPSUM DOLOR SIT AMET
        </p>
      </div>
      <div className="px-30 flex py-20">
        <div className="w-[50%] pr-20">
          <p className="text-[45px] font-serif font-[600]">Italian Food</p>
          <p className="text-[29px] leading-7 pr-6 mt-5 text-gray-500 font-[400]">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Ad itaque,
            nostrum inventore incidunt repellendus excepturi provident.
          </p>
          <div className="border-b-2  my-10 border-gray-500 "></div>
          <div className="flex text-black w-[30%] mt-5">
            <LogoBlack />
            <p className="text-[30px] pl-2 leading-8 font-serif font-[600]">
              Italian <br />
              Food
            </p>
          </div>
        </div>
        <div className="w-[50%] py-20 ">
          <div className="w-[100%] font-[700] text-gray-600 text-[30px] flex justify-around">
            <span>about</span>
            <span>about</span>
            <span>about</span>
          </div>
          <div className="border-b-4  mt-5 border-gray-500 "></div>
          <div className="w-[100%] mt-5 font-[500] text-gray-600 text-[20px] flex justify-around">
            {ar.map(()=>
              <div>
                <div>Team</div>
                <div>Join us</div>
                <div>Ethic</div>
                <div>Goals</div>
              </div>
            )}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
