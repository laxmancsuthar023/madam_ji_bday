import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUtensils } from "@fortawesome/free-solid-svg-icons";

const LogoIcon = () => {
  return (
    <FontAwesomeIcon icon={faUtensils} size="4x" color="#ffffff" />
  );
};

export default LogoIcon;